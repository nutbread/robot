Homepage: https://nutbread.github.io/robot/

To run, just execute robot.exe.
For a quick list of helpful options, run "help.bat".
The file "options.txt" explains some of the options in more detail.

The included sox.exe (v14.4.1) is third-party software used to play and filter sounds.
It's source code and licensing information (GPLv2) can be found here: http://sox.sourceforge.net/
You may feel free to download your own version and install it.

zlib1.dll is required for sox.exe to work properly.